/**
 * CineBook General Application Script
 * Modal handling, image fallbacks, toast alerts, and navigation.
 */

document.addEventListener("DOMContentLoaded", () => {
  // Graceful Image Fallbacks
  const images = document.querySelectorAll("img[data-fallback]");
  images.forEach((img) => {
    img.addEventListener("error", function () {
      const fallbackContainer = this.parentElement.querySelector(".poster-fallback");
      if (fallbackContainer) {
        fallbackContainer.style.display = "flex";
        this.style.display = "none";
      } else {
        // SVG inline placeholder
        this.src = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='450' viewBox='0 0 300 450' fill='%23121620'><rect width='300' height='450' fill='%23121620'/><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%2394A3B8' font-family='sans-serif' font-size='16'>CineBook Movie</text></svg>";
      }
    });
  });

  // Auto-dismiss alerts
  const autoAlerts = document.querySelectorAll(".alert");
  autoAlerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.transition = "opacity 0.4s ease, transform 0.4s ease";
      alert.style.opacity = "0";
      alert.style.transform = "translateY(-8px)";
      setTimeout(() => alert.remove(), 400);
    }, 6000);
  });

  // Cancellation Modal Logic
  const cancelModal = document.getElementById("cancel-booking-modal");
  const cancelButtons = document.querySelectorAll(".open-cancel-modal");
  const modalBookingIdEl = document.getElementById("modal-booking-id");
  const modalPaidAmountEl = document.getElementById("modal-paid-amount");
  const modalRefundAmountEl = document.getElementById("modal-refund-amount");
  const modalCancelForm = document.getElementById("modal-cancel-form");
  const modalCloseButtons = document.querySelectorAll(".close-modal-btn");

  if (cancelModal) {
    cancelButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const bookingId = btn.dataset.bookingId;
        const totalPaid = parseFloat(btn.dataset.totalPaid || 0);
        const refund = (totalPaid * 0.8).toFixed(2);

        if (modalBookingIdEl) modalBookingIdEl.textContent = bookingId;
        if (modalPaidAmountEl) modalPaidAmountEl.textContent = `₹${totalPaid.toFixed(2)}`;
        if (modalRefundAmountEl) modalRefundAmountEl.textContent = `₹${refund}`;

        if (modalCancelForm) {
          modalCancelForm.action = `/bookings/${bookingId}/cancel/`;
        }

        cancelModal.classList.add("active");
      });
    });

    modalCloseButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        cancelModal.classList.remove("active");
      });
    });

    cancelModal.addEventListener("click", (e) => {
      if (e.target === cancelModal) {
        cancelModal.classList.remove("active");
      }
    });
  }
});
