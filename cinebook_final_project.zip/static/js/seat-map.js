/**
 * CineBook Interactive Seat Map & Booking Handler
 * Controls 5x8 seat grid, live selection, coupon calculation, and atomic booking API calls.
 */

document.addEventListener("DOMContentLoaded", () => {
  const seatMapRoot = document.getElementById("seat-map-app");
  if (!seatMapRoot) return;

  const showId = seatMapRoot.dataset.showId;
  const isAuthenticated = seatMapRoot.dataset.userAuth === "true";
  const loginUrl = seatMapRoot.dataset.loginUrl || "/login/";

  // Pricing single-source lookup passed from Django template
  const pricingData = JSON.parse(seatMapRoot.dataset.pricing || "{}");

  // DOM Elements
  const seatButtons = document.querySelectorAll(".seat-btn:not(:disabled)");
  const selectedCountEl = document.getElementById("selected-count");
  const selectedChipsContainer = document.getElementById("selected-chips-container");
  const subtotalEl = document.getElementById("subtotal-display");
  const discountLine = document.getElementById("discount-line");
  const discountEl = document.getElementById("discount-display");
  const totalEl = document.getElementById("total-display");
  const couponInput = document.getElementById("coupon-input");
  const applyCouponBtn = document.getElementById("apply-coupon-btn");
  const couponMessageEl = document.getElementById("coupon-message");
  const bookNowBtn = document.getElementById("book-now-btn");
  const bookBtnText = document.getElementById("book-btn-text");
  const bookBtnSpinner = document.getElementById("book-btn-spinner");

  // State
  const selectedSeats = new Map(); // seatCode -> { row, num, type, price }
  let appliedCoupon = null; // { code, discountPercentage, discountAmount }

  // Helper to extract cookie value by name from document.cookie
  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== "") {
      const cookies = document.cookie.split(";");
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.substring(0, name.length + 1) === name + "=") {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }

  // Authoritative CSRF token: prioritize csrftoken cookie, with DOM fallback
  function getCsrfToken() {
    return (
      getCookie("csrftoken") ||
      document.querySelector('meta[name="csrf-token"]')?.getAttribute("content") ||
      document.querySelector('input[name="csrfmiddlewaretoken"]')?.value ||
      ""
    );
  }

  // Toast notification helper
  function showToast(message, type = "info") {
    let container = document.querySelector(".toast-container");
    if (!container) {
      container = document.createElement("div");
      container.className = "toast-container";
      document.body.appendChild(container);
    }
    const toast = document.createElement("div");
    toast.className = `toast toast-${type === "error" ? "error" : "success"}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(10px)";
      setTimeout(() => toast.remove(), 300);
    }, 4500);
  }

  // Calculate Subtotal & Totals
  function updateCalculations() {
    let subtotal = 0;
    selectedSeats.forEach((seat) => {
      subtotal += seat.price;
    });

    if (selectedCountEl) {
      selectedCountEl.textContent = selectedSeats.size;
    }

    if (subtotalEl) {
      subtotalEl.textContent = `₹${subtotal.toFixed(2)}`;
    }

    let discount = 0;
    if (appliedCoupon && subtotal > 0) {
      discount = (subtotal * appliedCoupon.discountPercentage) / 100;
      if (discountLine) discountLine.style.display = "flex";
      if (discountEl) discountEl.textContent = `-₹${discount.toFixed(2)}`;
    } else {
      if (discountLine) discountLine.style.display = "none";
    }

    const finalTotal = Math.max(0, subtotal - discount);
    if (totalEl) {
      totalEl.textContent = `₹${finalTotal.toFixed(2)}`;
    }

    // Render chips
    renderChips();

    // Enable / disable booking CTA
    if (bookNowBtn) {
      bookNowBtn.disabled = selectedSeats.size === 0;
    }
  }

  function renderChips() {
    if (!selectedChipsContainer) return;
    selectedChipsContainer.innerHTML = "";

    if (selectedSeats.size === 0) {
      selectedChipsContainer.innerHTML = '<span class="text-dim" style="font-size: 0.85rem;">No seats selected yet. Click any seat on the map.</span>';
      return;
    }

    selectedSeats.forEach((seat, code) => {
      const chip = document.createElement("div");
      chip.className = "seat-chip";
      chip.innerHTML = `
        <span>${code}</span>
        <span class="text-muted" style="font-size: 0.75rem;">(₹${seat.price.toFixed(0)})</span>
        <span class="remove-btn" title="Deselect">&times;</span>
      `;
      chip.querySelector(".remove-btn").addEventListener("click", () => {
        toggleSeat(code, seat.row, seat.num, seat.type, seat.price);
      });
      selectedChipsContainer.appendChild(chip);
    });
  }

  function toggleSeat(code, row, num, type, price) {
    const btn = document.querySelector(`.seat-btn[data-seat-code="${code}"]`);
    if (selectedSeats.has(code)) {
      selectedSeats.delete(code);
      if (btn) btn.classList.remove("selected");
    } else {
      selectedSeats.set(code, { row, num, type, price });
      if (btn) btn.classList.add("selected");
    }
    updateCalculations();
  }

  // Seat Button Click Handlers
  seatButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      if (btn.disabled || btn.classList.contains("booked")) return;
      const code = btn.dataset.seatCode;
      const row = btn.dataset.row;
      const num = parseInt(btn.dataset.number, 10);
      const type = btn.dataset.type;
      const price = parseFloat(btn.dataset.price);

      toggleSeat(code, row, num, type, price);
    });
  });

  // Apply Coupon
  if (applyCouponBtn && couponInput) {
    applyCouponBtn.addEventListener("click", async () => {
      const code = couponInput.value.trim().toUpperCase();
      if (!code) {
        showToast("Please enter a coupon code.", "error");
        return;
      }

      let subtotal = 0;
      selectedSeats.forEach((s) => (subtotal += s.price));

      try {
        const response = await fetch("/api/coupons/validate/", {
          method: "POST",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCsrfToken(),
          },
          body: JSON.stringify({ code: code, subtotal: subtotal }),
        });
        const result = await response.json();

        if (result.valid) {
          appliedCoupon = {
            code: result.code,
            discountPercentage: result.discount_percentage,
            discountAmount: result.discount_amount,
          };
          if (couponMessageEl) {
            couponMessageEl.style.display = "block";
            couponMessageEl.style.color = "#4ADE80";
            couponMessageEl.textContent = result.message;
          }
          showToast(result.message, "success");
        } else {
          appliedCoupon = null;
          if (couponMessageEl) {
            couponMessageEl.style.display = "block";
            couponMessageEl.style.color = "#FF6B6B";
            couponMessageEl.textContent = result.message || "Invalid coupon code.";
          }
          showToast(result.message || "Invalid coupon code.", "error");
        }
        updateCalculations();
      } catch (err) {
        showToast("Error validating coupon code.", "error");
      }
    });
  }

  // Confirm Booking Submission
  if (bookNowBtn) {
    bookNowBtn.addEventListener("click", async () => {
      if (selectedSeats.size === 0) {
        showToast("Please select at least one seat to book.", "error");
        return;
      }

      if (!isAuthenticated) {
        // Redirect to login preserving intended seat reservation destination
        showToast("Please log in to confirm your booking.", "info");
        setTimeout(() => {
          window.location.href = `${loginUrl}?next=${encodeURIComponent(window.location.pathname)}`;
        }, 600);
        return;
      }

      const seatCodes = Array.from(selectedSeats.keys());
      const couponCode = appliedCoupon ? appliedCoupon.code : couponInput ? couponInput.value.trim() : "";

      // Loading state
      bookNowBtn.disabled = true;
      if (bookBtnText) bookBtnText.textContent = "Reserving Seats...";
      if (bookBtnSpinner) bookBtnSpinner.style.display = "inline-block";

      try {
        const response = await fetch("/api/bookings/create/", {
          method: "POST",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCsrfToken(),
          },
          body: JSON.stringify({
            show_id: parseInt(showId, 10),
            seat_codes: seatCodes,
            coupon_code: couponCode,
          }),
        });

        const result = await response.json();

        if (response.ok && result.success) {
          showToast("Booking confirmed! Redirecting to ticket...", "success");
          setTimeout(() => {
            window.location.href = result.redirect_url;
          }, 500);
        } else {
          // Re-enable button
          bookNowBtn.disabled = false;
          if (bookBtnText) bookBtnText.textContent = "Confirm & Book Tickets";
          if (bookBtnSpinner) bookBtnSpinner.style.display = "none";

          if (response.status === 409) {
            // Seat conflict
            showToast(result.error, "error");
            // Mark those seats as booked visually and deselect
            refreshSeatAvailability();
          } else if (response.status === 401 && result.redirect_url) {
            window.location.href = result.redirect_url;
          } else {
            showToast(result.error || "Unable to complete booking.", "error");
          }
        }
      } catch (err) {
        bookNowBtn.disabled = false;
        if (bookBtnText) bookBtnText.textContent = "Confirm & Book Tickets";
        if (bookBtnSpinner) bookBtnSpinner.style.display = "none";
        showToast("Network error. Please check connection and try again.", "error");
      }
    });
  }

  // Refresh seat availability from API
  async function refreshSeatAvailability() {
    try {
      const resp = await fetch(`/api/shows/${showId}/seats/`, {
        credentials: "same-origin",
      });
      if (resp.ok) {
        const data = await resp.json();
        data.seat_matrix.forEach((row) => {
          row.forEach((seat) => {
            const btn = document.querySelector(`.seat-btn[data-seat-code="${seat.seat_code}"]`);
            if (btn && seat.is_booked) {
              btn.classList.add("booked");
              btn.classList.remove("selected");
              btn.disabled = true;
              selectedSeats.delete(seat.seat_code);
            }
          });
        });
        updateCalculations();
      }
    } catch (e) {
      console.warn("Failed to refresh seat availability:", e);
    }
  }

  // Initial Calculation
  updateCalculations();
});
