from django.shortcuts import render


def error_403(request, exception=None):
    return render(request, "403.html", {"title": "403 Forbidden"}, status=403)


def error_404(request, exception=None):
    return render(request, "404.html", {"title": "404 Not Found"}, status=404)


def error_500(request):
    return render(request, "500.html", {"title": "500 Server Error"}, status=500)
