from django.db import models
from django.utils.text import slugify


class Movie(models.Model):
    """
    Represents a cinematic film in CineBook catalog.
    """
    title = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    description = models.TextField()
    poster_url = models.URLField(max_length=500)
    backdrop_url = models.URLField(max_length=500, blank=True, default="")
    genre = models.CharField(max_length=100, db_index=True)
    language = models.CharField(max_length=50, default="English", db_index=True)
    duration_minutes = models.PositiveIntegerField(help_text="Runtime in minutes")
    rating = models.DecimalField(max_digits=3, decimal_places=1, default=8.0)
    release_date = models.DateField()
    is_now_showing = models.BooleanField(default=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-is_now_showing", "-release_date", "title"]

    def __str__(self):
        return f"{self.title} ({self.language})"

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title) or "movie"
            slug = base_slug
            counter = 1
            while Movie.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    @property
    def duration_formatted(self) -> str:
        """Returns runtime formatted as '2h 45m'"""
        hours = self.duration_minutes // 60
        mins = self.duration_minutes % 60
        if hours and mins:
            return f"{hours}h {mins}m"
        elif hours:
            return f"{hours}h"
        return f"{mins}m"
