from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from datetime import date
from django.views.decorators.csrf import ensure_csrf_cookie
from movies.models import Movie
from cinema.models import Show, schedule_upcoming_shows


@ensure_csrf_cookie
def home_view(request):
    """
    Renders CineBook home page:
    - Hero showcase
    - Now Showing movies with search and filters
    - Upcoming movies
    """
    today = date.today()
    if Show.objects.filter(show_date__gte=today, is_active=True).count() == 0:
        schedule_upcoming_shows(7)

    query = request.GET.get("q", "").strip()
    selected_genre = request.GET.get("genre", "").strip()
    selected_lang = request.GET.get("lang", "").strip()

    now_showing_qs = Movie.objects.filter(is_now_showing=True)
    upcoming_qs = Movie.objects.filter(is_now_showing=False)

    if query:
        search_filter = Q(title__icontains=query) | Q(genre__icontains=query) | Q(description__icontains=query)
        now_showing_qs = now_showing_qs.filter(search_filter)
        upcoming_qs = upcoming_qs.filter(search_filter)

    if selected_genre:
        now_showing_qs = now_showing_qs.filter(genre__icontains=selected_genre)
        upcoming_qs = upcoming_qs.filter(genre__icontains=selected_genre)

    if selected_lang:
        now_showing_qs = now_showing_qs.filter(language__iexact=selected_lang)
        upcoming_qs = upcoming_qs.filter(language__iexact=selected_lang)

    # Hero featured movie (prefer Interstellar or highest rating)
    featured_movie = now_showing_qs.order_by("-rating").first() or Movie.objects.filter(is_now_showing=True).first()

    # Collect distinct genres and languages for filter buttons
    all_movies = Movie.objects.all()
    genre_set = set()
    for m in all_movies:
        for g in m.genre.split(","):
            if g.strip():
                genre_set.add(g.strip())
    genres = sorted(list(genre_set))

    languages = sorted(list(Movie.objects.values_list("language", flat=True).distinct()))

    context = {
        "featured_movie": featured_movie,
        "now_showing": now_showing_qs,
        "upcoming_movies": upcoming_qs,
        "genres": genres,
        "languages": languages,
        "search_query": query,
        "selected_genre": selected_genre,
        "selected_lang": selected_lang,
    }
    return render(request, "movies/home.html", context)


@ensure_csrf_cookie
def movie_detail_view(request, movie_id=None, slug=None):
    """
    Renders detailed view for a movie along with upcoming shows grouped by date.
    Supports lookup by integer movie_id or string slug.
    """
    if movie_id:
        movie = get_object_or_404(Movie, id=movie_id)
    else:
        movie = get_object_or_404(Movie, slug=slug)

    today = date.today()
    # Fetch active shows for this movie from today onwards
    shows = (
        Show.objects.filter(movie=movie, is_active=True, show_date__gte=today)
        .select_related("theatre")
        .order_by("show_date", "start_time")
    )

    if shows.count() == 0 and movie.is_now_showing:
        schedule_upcoming_shows(7)
        shows = (
            Show.objects.filter(movie=movie, is_active=True, show_date__gte=today)
            .select_related("theatre")
            .order_by("show_date", "start_time")
        )

    # Group shows by date: { date_obj: [shows] }
    shows_by_date = {}
    for show in shows:
        shows_by_date.setdefault(show.show_date, []).append(show)

    context = {
        "movie": movie,
        "shows_by_date": shows_by_date,
        "total_shows": shows.count(),
    }
    return render(request, "movies/movie_detail.html", context)
