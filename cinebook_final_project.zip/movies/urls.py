from django.urls import path
from movies import views

urlpatterns = [
    path("", views.home_view, name="home"),
    path("movies/<int:movie_id>/", views.movie_detail_view, name="movie_detail"),
    path("movies/slug/<slug:slug>/", views.movie_detail_view, name="movie_detail_slug"),
]
