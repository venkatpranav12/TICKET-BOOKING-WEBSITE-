from django.contrib import admin
from movies.models import Movie


@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ("title", "genre", "language", "duration_minutes", "rating", "is_now_showing", "release_date")
    list_filter = ("is_now_showing", "language", "genre")
    search_fields = ("title", "description")
    prepopulated_fields = {"slug": ("title",)}
