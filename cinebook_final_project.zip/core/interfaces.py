"""
Core Interfaces and Abstract Base Classes for CineBook.
Defines OOP contracts for the booking domain.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Any
from django.contrib.auth.models import User


class Bookable(ABC):
    """
    Abstract Base Class defining the contract for booking systems.
    Corresponds to Java's interface Bookable in the academic OOP design.
    """

    @abstractmethod
    def book_seats(
        self,
        user: User,
        show_id: int,
        seat_codes: List[str],
        coupon_code: Optional[str] = None
    ) -> Any:
        """
        Reserve selected seats atomically and create a confirmed booking.

        Args:
            user: Authenticated Django User
            show_id: Primary key of Show
            seat_codes: List of seat codes (e.g., ['A1', 'A2'])
            coupon_code: Optional coupon discount code

        Returns:
            Booking instance upon success

        Raises:
            ValidationError or BookingError on failure
        """
        pass

    @abstractmethod
    def cancel_booking(self, user: User, booking_id: str) -> Any:
        """
        Cancel a confirmed booking, release seats, and compute the 80% refund.

        Args:
            user: Requesting user (must own the booking)
            booking_id: Public unique booking identifier (e.g., 'BK1001')

        Returns:
            Dictionary or tuple with cancellation details and refund breakdown
        """
        pass
