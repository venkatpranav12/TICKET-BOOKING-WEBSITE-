"""
Core utility functions and custom exceptions for CineBook.
"""

from decimal import Decimal
import re
from typing import Tuple


class CineBookException(Exception):
    """Base exception for CineBook domain errors."""
    pass


class BookingError(CineBookException):
    """Raised when seat booking validation or execution fails."""
    pass


class SeatUnavailableError(BookingError):
    """Raised when one or more requested seats are already booked."""
    pass


class InvalidSeatCodeError(BookingError):
    """Raised when seat codes are malformed or out of range."""
    pass


class CouponError(CineBookException):
    """Raised when coupon code validation fails."""
    pass


class CancellationError(CineBookException):
    """Raised when booking cancellation fails."""
    pass


VALID_ROWS = ("A", "B", "C", "D", "E")
VALID_SEAT_NUMBERS = range(1, 9)  # 1 to 8


def parse_and_validate_seat_code(raw_code: str) -> Tuple[str, int]:
    """
    Validates and normalizes seat codes like 'A1', 'e8', ' b 3 '.
    Rejects invalid values such as 'Z9', 'A0', 'A9', blank strings, etc.

    Returns:
        (row_label, seat_number): e.g. ('A', 1)
    """
    if not raw_code or not isinstance(raw_code, str):
        raise InvalidSeatCodeError("Seat code cannot be empty.")

    cleaned = raw_code.strip().upper()
    match = re.match(r"^([A-Z])(\d+)$", cleaned)
    if not match:
        raise InvalidSeatCodeError(
            f"Invalid seat code format '{cleaned}'. Expected format: Letter + Number (e.g., A1, E8)."
        )

    row, num_str = match.groups()
    seat_num = int(num_str)

    if row not in VALID_ROWS:
        raise InvalidSeatCodeError(
            f"Row '{row}' is invalid. Allowed rows are A, B, C, D, E."
        )

    if seat_num not in VALID_SEAT_NUMBERS:
        raise InvalidSeatCodeError(
            f"Seat number '{seat_num}' is invalid. Allowed seats per row are 1 to 8."
        )

    return row, seat_num


def format_inr(amount: Decimal | float | int) -> str:
    """
    Formats a numeric amount into Indian Rupee string format.
    E.g., Decimal('450.00') -> '₹450.00'
    """
    if amount is None:
        amount = Decimal("0.00")
    if not isinstance(amount, Decimal):
        amount = Decimal(str(amount))
    return f"₹{amount:,.2f}"
