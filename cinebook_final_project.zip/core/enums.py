"""
Core Enumerations for CineBook.
Defines seat types with domain prices and booking statuses.
Acts as the single source of truth for seat pricing and categories.
"""

from decimal import Decimal
from enum import Enum
from typing import Optional


class SeatType(Enum):
    """
    Seat category enumeration with pricing according to CineBook business rules:
    - Rows A, B: REGULAR = ₹150.00
    - Rows C, D: PREMIUM = ₹250.00
    - Row E: VIP = ₹400.00
    """
    REGULAR = ("REGULAR", "Regular", Decimal("150.00"), ("A", "B"))
    PREMIUM = ("PREMIUM", "Premium", Decimal("250.00"), ("C", "D"))
    VIP = ("VIP", "VIP", Decimal("400.00"), ("E",))

    def __init__(self, code: str, label: str, price: Decimal, rows: tuple):
        self._code = code
        self._label = label
        self._price = price
        self._rows = rows

    @property
    def code(self) -> str:
        return self._code

    @property
    def label(self) -> str:
        return self._label

    @property
    def price(self) -> Decimal:
        return self._price

    @property
    def rows(self) -> tuple:
        return self._rows

    @classmethod
    def from_row(cls, row_label: str) -> "SeatType":
        """
        Derive SeatType from row label (A-E).
        """
        row = (row_label or "").strip().upper()
        if row in ("A", "B"):
            return cls.REGULAR
        elif row in ("C", "D"):
            return cls.PREMIUM
        elif row == "E":
            return cls.VIP
        raise ValueError(f"Invalid row label '{row_label}'. Allowed rows: A, B, C, D, E.")

    @classmethod
    def from_code(cls, code: str) -> "SeatType":
        """
        Map string code (e.g. 'REGULAR', 'PREMIUM', 'VIP') to SeatType enum.
        """
        normalized = (code or "").strip().upper()
        for item in cls:
            if item.code == normalized:
                return item
        raise ValueError(f"Unknown seat type code '{code}'. Allowed: REGULAR, PREMIUM, VIP.")

    @classmethod
    def choices(cls):
        """
        Django model field choices tuple.
        """
        return [(item.code, f"{item.label} (₹{item.price:.2f})") for item in cls]

    @classmethod
    def to_pricing_dict(cls) -> dict:
        """
        Returns JSON-serializable pricing mapping for frontend display.
        """
        return {
            item.code: {
                "code": item.code,
                "label": item.label,
                "price": float(item.price),
                "formatted_price": f"₹{item.price:.2f}",
                "rows": list(item.rows)
            }
            for item in cls
        }


class BookingStatus(Enum):
    """
    Booking status lifecycle enumeration.
    """
    CONFIRMED = ("CONFIRMED", "Confirmed")
    CANCELLED = ("CANCELLED", "Cancelled")

    def __init__(self, code: str, label: str):
        self._code = code
        self._label = label

    @property
    def code(self) -> str:
        return self._code

    @property
    def label(self) -> str:
        return self._label

    @classmethod
    def choices(cls):
        return [(item.code, item.label) for item in cls]
