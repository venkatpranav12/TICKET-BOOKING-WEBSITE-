from django.contrib import admin
from bookings.models import Booking, BookingSeat, Coupon


class BookingSeatInline(admin.TabularInline):
    model = BookingSeat
    extra = 0
    readonly_fields = ("seat_code", "row_label", "seat_number", "seat_type", "price_snapshot")
    can_delete = False


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("booking_id", "user", "show", "subtotal", "total_amount", "refund_amount", "status", "created_at")
    list_filter = ("status", "created_at")
    search_fields = ("booking_id", "user__username", "user__email", "show__movie__title")
    inlines = [BookingSeatInline]


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ("code", "discount_percentage", "maximum_discount", "is_active", "valid_from", "valid_until")
    list_filter = ("is_active",)
    search_fields = ("code",)
