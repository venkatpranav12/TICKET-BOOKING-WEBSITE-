"""
Automated Test Suite for CineBook.
Tests all domain requirements:
- Seat generation & pricing enum
- Atomic bookings & all-or-nothing rollback
- Validation of seat codes (invalid, duplicate, already-booked)
- CINE10 coupon logic
- Booking ID generation
- Independent show inventories
- Cancellation & 80% refund policy
- Access control & ownership
- Seat restoration after cancellation
- 2D matrix structure
"""

from datetime import date, time
from decimal import Decimal
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from core.enums import SeatType, BookingStatus
from core.utils import (
    BookingError,
    SeatUnavailableError,
    InvalidSeatCodeError,
    CouponError,
    CancellationError,
    parse_and_validate_seat_code
)
from movies.models import Movie
from cinema.models import Theatre, Show, Seat
from bookings.models import Booking, BookingSeat, Coupon
from bookings.services import (
    BookingService,
    BookingIdGenerator,
    calculate_total,
    build_seat_matrix_2d
)


class CineBookDomainTests(TestCase):
    def setUp(self):
        # Create users
        self.user_alice = User.objects.create_user(username="alice", password="Password@123", email="alice@test.com")
        self.user_bob = User.objects.create_user(username="bob", password="Password@123", email="bob@test.com")

        # Create Movie
        self.movie = Movie.objects.create(
            title="Interstellar",
            slug="interstellar",
            description="Deep space exploration.",
            poster_url="https://example.com/poster.jpg",
            genre="Sci-Fi",
            language="English",
            duration_minutes=169,
            rating=Decimal("8.7"),
            release_date=date(2014, 11, 7),
            is_now_showing=True,
        )

        # Create Theatre
        self.theatre = Theatre.objects.create(
            name="CineBook Dolby Grand",
            screen_name="Audi 1",
            location="Downtown",
            is_active=True,
        )

        # Create Show 1
        self.show1 = Show.objects.create(
            movie=self.movie,
            theatre=self.theatre,
            show_date=date.today(),
            start_time=time(14, 30),
            is_active=True,
        )

        # Create Show 2
        self.show2 = Show.objects.create(
            movie=self.movie,
            theatre=self.theatre,
            show_date=date.today(),
            start_time=time(18, 45),
            is_active=True,
        )

        # Generate 40 seats (5 rows A-E x 8 cols 1-8) for show 1
        self._generate_seats_for_show(self.show1)
        # Generate 40 seats for show 2
        self._generate_seats_for_show(self.show2)

        # Create Coupon CINE10
        self.coupon_cine10 = Coupon.objects.create(
            code="CINE10",
            discount_percentage=Decimal("10.00"),
            is_active=True,
            maximum_discount=Decimal("500.00")
        )

        self.service = BookingService()
        self.client = Client()

    def _generate_seats_for_show(self, show):
        show.generate_seats_if_needed()

    # 1. Seat Generation & Pricing
    def test_seat_category_mapping_and_pricing(self):
        """Verify seat types and prices: A,B=150, C,D=250, E=400"""
        self.assertEqual(SeatType.from_row("A").price, Decimal("150.00"))
        self.assertEqual(SeatType.from_row("B").price, Decimal("150.00"))
        self.assertEqual(SeatType.from_row("C").price, Decimal("250.00"))
        self.assertEqual(SeatType.from_row("D").price, Decimal("250.00"))
        self.assertEqual(SeatType.from_row("E").price, Decimal("400.00"))

        seat_a1 = Seat.objects.get(show=self.show1, row_label="A", seat_number=1)
        self.assertEqual(seat_a1.seat_type, SeatType.REGULAR.code)
        self.assertEqual(seat_a1.price, Decimal("150.00"))

        seat_c1 = Seat.objects.get(show=self.show1, row_label="C", seat_number=1)
        self.assertEqual(seat_c1.seat_type, SeatType.PREMIUM.code)
        self.assertEqual(seat_c1.price, Decimal("250.00"))

        seat_e1 = Seat.objects.get(show=self.show1, row_label="E", seat_number=1)
        self.assertEqual(seat_e1.seat_type, SeatType.VIP.code)
        self.assertEqual(seat_e1.price, Decimal("400.00"))

    # 2. Book Single Seat
    def test_book_single_seat(self):
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["A1"])
        self.assertEqual(booking.status, BookingStatus.CONFIRMED.code)
        self.assertEqual(booking.total_amount, Decimal("150.00"))
        self.assertEqual(booking.subtotal, Decimal("150.00"))
        self.assertEqual(booking.discount_amount, Decimal("0.00"))
        self.assertTrue(booking.booking_id.startswith("BK"))

        seat_a1 = Seat.objects.get(show=self.show1, row_label="A", seat_number=1)
        self.assertTrue(seat_a1.is_booked)
        self.assertEqual(booking.booking_seats.count(), 1)
        self.assertEqual(booking.booking_seats.first().seat_code, "A1")

    # 3. Book Multiple Seats
    def test_book_multiple_seats(self):
        # C1 (250) + E1 (400) = 650
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["C1", "E1"])
        self.assertEqual(booking.total_amount, Decimal("650.00"))
        self.assertEqual(booking.booking_seats.count(), 2)

        c1 = Seat.objects.get(show=self.show1, row_label="C", seat_number=1)
        e1 = Seat.objects.get(show=self.show1, row_label="E", seat_number=1)
        self.assertTrue(c1.is_booked)
        self.assertTrue(e1.is_booked)

    # 4. Invalid Seat Codes
    def test_invalid_seat_codes(self):
        with self.assertRaises(InvalidSeatCodeError):
            parse_and_validate_seat_code("Z9")

        with self.assertRaises(InvalidSeatCodeError):
            parse_and_validate_seat_code("A0")

        with self.assertRaises(InvalidSeatCodeError):
            parse_and_validate_seat_code("A9")

        with self.assertRaises(InvalidSeatCodeError):
            self.service.book_seats(self.user_alice, self.show1.id, ["Z1"])

        with self.assertRaises(InvalidSeatCodeError):
            self.service.book_seats(self.user_alice, self.show1.id, [])

    # 5. Duplicate Seat Codes
    def test_duplicate_seat_codes(self):
        with self.assertRaises(InvalidSeatCodeError):
            self.service.book_seats(self.user_alice, self.show1.id, ["A1", "A1"])

        with self.assertRaises(InvalidSeatCodeError):
            self.service.book_seats(self.user_alice, self.show1.id, ["B2", "b2"])

    # 6. Booking Already Booked Seats
    def test_book_already_booked_seat(self):
        self.service.book_seats(self.user_alice, self.show1.id, ["B3"])
        with self.assertRaises(SeatUnavailableError):
            self.service.book_seats(self.user_bob, self.show1.id, ["B3"])

    # 7. All-or-Nothing Atomicity
    def test_all_or_nothing_behavior(self):
        # Pre-book B4
        self.service.book_seats(self.user_alice, self.show1.id, ["B4"])

        # Bob attempts to book B3 and B4
        with self.assertRaises(SeatUnavailableError):
            self.service.book_seats(self.user_bob, self.show1.id, ["B3", "B4"])

        # B3 must NOT be booked due to atomic rollback
        seat_b3 = Seat.objects.get(show=self.show1, row_label="B", seat_number=3)
        self.assertFalse(seat_b3.is_booked)

    # 8. Coupon Calculation
    def test_cine10_coupon_calculation(self):
        # 2 Premium seats = 2 x 250 = 500
        # 10% discount = 50. Total = 450
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["C1", "C2"], coupon_code="CINE10")
        self.assertEqual(booking.subtotal, Decimal("500.00"))
        self.assertEqual(booking.discount_amount, Decimal("50.00"))
        self.assertEqual(booking.total_amount, Decimal("450.00"))
        self.assertEqual(booking.coupon_code, "CINE10")

    # 9. Invalid Coupon Rejection
    def test_invalid_coupon_rejection(self):
        with self.assertRaises(CouponError):
            self.service.book_seats(self.user_alice, self.show1.id, ["A1"], coupon_code="FAKE99")

        # Inactive coupon
        Coupon.objects.create(code="EXPIRED", discount_percentage=Decimal("20.00"), is_active=False)
        with self.assertRaises(CouponError):
            self.service.book_seats(self.user_alice, self.show1.id, ["A1"], coupon_code="EXPIRED")

    # 10. Booking ID Generation
    def test_booking_id_generation_and_uniqueness(self):
        b1 = self.service.book_seats(self.user_alice, self.show1.id, ["A1"])
        b2 = self.service.book_seats(self.user_alice, self.show1.id, ["A2"])
        self.assertNotEqual(b1.booking_id, b2.booking_id)
        self.assertTrue(b1.booking_id.startswith("BK"))
        self.assertTrue(b2.booking_id.startswith("BK"))

    # 11. Independent Seat Grids Across Shows
    def test_independent_seat_grids_across_shows(self):
        # Book A1 in Show 1
        self.service.book_seats(self.user_alice, self.show1.id, ["A1"])
        seat_show1_a1 = Seat.objects.get(show=self.show1, row_label="A", seat_number=1)
        self.assertTrue(seat_show1_a1.is_booked)

        # A1 in Show 2 MUST remain available
        seat_show2_a1 = Seat.objects.get(show=self.show2, row_label="A", seat_number=1)
        self.assertFalse(seat_show2_a1.is_booked)

        # Bob can book A1 in Show 2 without conflict
        booking_show2 = self.service.book_seats(self.user_bob, self.show2.id, ["A1"])
        self.assertEqual(booking_show2.status, BookingStatus.CONFIRMED.code)

    # 12. Cancellation and 80% Refund
    def test_cancellation_and_80_percent_refund(self):
        # 2 VIP seats = 2 x 400 = 800
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["E1", "E2"])
        self.assertEqual(booking.total_amount, Decimal("800.00"))

        cancel_data = self.service.cancel_booking(self.user_alice, booking.booking_id)
        self.assertEqual(cancel_data["refund_percentage"], 80)
        self.assertEqual(cancel_data["refund_amount"], Decimal("640.00"))  # 800 * 0.80 = 640.00
        self.assertEqual(cancel_data["cancellation_fee"], Decimal("160.00"))  # 800 * 0.20 = 160.00

        # Reload booking from DB
        booking.refresh_from_db()
        self.assertEqual(booking.status, BookingStatus.CANCELLED.code)
        self.assertEqual(booking.refund_amount, Decimal("640.00"))
        self.assertIsNotNone(booking.cancelled_at)

    # 13. Prevention of Duplicate Cancellations
    def test_prevention_of_duplicate_cancellations(self):
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["A5"])
        self.service.cancel_booking(self.user_alice, booking.booking_id)

        # Attempt to cancel second time
        with self.assertRaises(CancellationError):
            self.service.cancel_booking(self.user_alice, booking.booking_id)

    # 14. Seat Availability After Cancellation
    def test_seat_availability_after_cancellation(self):
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["D5"])
        seat_d5 = Seat.objects.get(show=self.show1, row_label="D", seat_number=5)
        self.assertTrue(seat_d5.is_booked)

        self.service.cancel_booking(self.user_alice, booking.booking_id)
        seat_d5.refresh_from_db()
        self.assertFalse(seat_d5.is_booked)

        # Bob can now book D5
        b_bob = self.service.book_seats(self.user_bob, self.show1.id, ["D5"])
        self.assertEqual(b_bob.status, BookingStatus.CONFIRMED.code)

        # Historical booking seat records for Alice's cancelled booking are still intact!
        booking.refresh_from_db()
        self.assertEqual(booking.booking_seats.count(), 1)
        self.assertEqual(booking.booking_seats.first().seat_code, "D5")

    # 15. Access Control & Prevention of Unauthorized Cancellation
    def test_unauthorized_cancellation(self):
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["C5"])

        # Bob attempts to cancel Alice's booking
        with self.assertRaises(CancellationError):
            self.service.cancel_booking(self.user_bob, booking.booking_id)

    def test_unauthorized_ticket_view(self):
        booking = self.service.book_seats(self.user_alice, self.show1.id, ["C6"])
        self.client.force_login(self.user_bob)

        # Bob tries to view Alice's booking page
        resp = self.client.get(reverse("booking_confirmation", kwargs={"booking_id": booking.booking_id}))
        self.assertEqual(resp.status_code, 403)

    # 16. Two-Dimensional Array Representation
    def test_2d_array_seat_matrix_structure(self):
        matrix = build_seat_matrix_2d(self.show1)
        # Must be 5 rows (A-E)
        self.assertEqual(len(matrix), 5)
        # Each row must have 8 columns (1-8)
        for row_idx, row in enumerate(matrix):
            self.assertEqual(len(row), 8)
            for col_idx, seat in enumerate(row):
                self.assertEqual(seat["matrix_coords"], (row_idx, col_idx))
                self.assertEqual(seat["row_label"], ["A", "B", "C", "D", "E"][row_idx])
                self.assertEqual(seat["seat_number"], col_idx + 1)

    # 17. REST API Flow
    def test_booking_api_flow(self):
        self.client.force_login(self.user_alice)
        payload = {
            "show_id": self.show1.id,
            "seat_codes": ["B1", "B2"],
            "coupon_code": "CINE10",
        }
        resp = self.client.post(
            reverse("api_booking_create"),
            data=payload,
            content_type="application/json"
        )
        self.assertEqual(resp.status_code, 201)
        data = resp.json()
        self.assertTrue(data["success"])
        self.assertEqual(data["subtotal"], 300.00)  # 2 x 150
        self.assertEqual(data["discount"], 30.00)  # 10% of 300
        self.assertEqual(data["total_amount"], 270.00)

        # API seat map endpoint
        map_resp = self.client.get(reverse("api_show_seats", kwargs={"show_id": self.show1.id}))
        self.assertEqual(map_resp.status_code, 200)
        map_data = map_resp.json()
        self.assertEqual(len(map_data["seat_matrix"]), 5)
