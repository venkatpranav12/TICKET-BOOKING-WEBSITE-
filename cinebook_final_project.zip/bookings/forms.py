from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class CineBookRegistrationForm(UserCreationForm):
    """
    Registration form with custom styled inputs and email collection.
    """
    first_name = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "placeholder": "First Name",
            "autocomplete": "given-name",
        })
    )
    last_name = forms.CharField(
        max_length=50,
        required=False,
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "placeholder": "Last Name",
            "autocomplete": "family-name",
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            "class": "form-control",
            "placeholder": "name@example.com",
            "autocomplete": "email",
        })
    )

    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.update({
            "class": "form-control",
            "placeholder": "Choose a username",
            "autocomplete": "username",
        })
        self.fields["username"].help_text = "Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only."
        if "password1" in self.fields:
            self.fields["password1"].widget.attrs.update({
                "class": "form-control",
                "placeholder": "Enter a strong password",
            })
        if "password2" in self.fields:
            self.fields["password2"].widget.attrs.update({
                "class": "form-control",
                "placeholder": "Confirm password",
            })

    def clean_email(self):
        email = self.cleaned_data.get("email")
        if email and User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email
