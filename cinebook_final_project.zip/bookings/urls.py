from django.urls import path
from bookings import views

urlpatterns = [
    # Template Views
    path("bookings/", views.my_bookings_view, name="my_bookings"),
    path("bookings/<str:booking_id>/", views.booking_confirmation_view, name="booking_confirmation"),
    path("bookings/<str:booking_id>/cancel/", views.cancel_booking_view, name="cancel_booking"),

    # REST APIs
    path("api/bookings/create/", views.booking_create_api, name="api_booking_create"),
    path("api/bookings/<str:booking_id>/", views.booking_detail_api, name="api_booking_detail"),
    path("api/bookings/<str:booking_id>/cancel/", views.booking_detail_api, name="api_booking_cancel"),
    path("api/coupons/validate/", views.coupon_validate_api, name="api_coupon_validate"),

    # Custom Auth Routes
    path("accounts/login/", views.login_view, name="login"),
    path("accounts/register/", views.register_view, name="register"),
    path("accounts/logout/", views.logout_view, name="logout"),
    path("login/", views.login_view, name="login_alias"),
    path("register/", views.register_view, name="register_alias"),
    path("logout/", views.logout_view, name="logout_alias"),
]
