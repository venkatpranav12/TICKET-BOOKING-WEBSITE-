import json
from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseForbidden
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST, require_http_methods
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib import messages
from django.urls import reverse
from core.enums import BookingStatus
from core.utils import (
    BookingError,
    SeatUnavailableError,
    InvalidSeatCodeError,
    CouponError,
    CancellationError,
    format_inr
)
from bookings.models import Booking, Coupon
from bookings.services import BookingService, calculate_total
from bookings.forms import CineBookRegistrationForm
from cinema.models import Show


# ============================================================================
# API ENDPOINTS
# ============================================================================

@require_POST
def booking_create_api(request):
    """
    POST /api/bookings/create/
    Atomic booking endpoint called via Fetch API or AJAX.
    Payload: { "show_id": 1, "seat_codes": ["A1", "A2"], "coupon_code": "CINE10" }
    """
    if not request.user.is_authenticated:
        return JsonResponse({
            "success": False,
            "error": "Authentication required. Please log in to complete your booking.",
            "login_required": True,
            "redirect_url": f"{reverse('login')}?next={request.META.get('HTTP_REFERER', '/')}"
        }, status=401)

    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        # Fallback to form data
        data = request.POST

    show_id = data.get("show_id")
    seat_codes = data.get("seat_codes", [])
    coupon_code = data.get("coupon_code", "")

    if not show_id:
        return JsonResponse({"success": False, "error": "Show ID is required."}, status=400)

    try:
        show_id = int(show_id)
    except (ValueError, TypeError):
        return JsonResponse({"success": False, "error": "Invalid Show ID."}, status=400)

    if isinstance(seat_codes, str):
        seat_codes = [s.strip() for s in seat_codes.split(",") if s.strip()]

    if not seat_codes:
        return JsonResponse({"success": False, "error": "Please select at least one seat."}, status=400)

    service = BookingService()
    try:
        booking = service.book_seats(
            user=request.user,
            show_id=show_id,
            seat_codes=seat_codes,
            coupon_code=coupon_code if coupon_code else None
        )

        messages.success(request, f"Booking confirmed! Booking ID: {booking.booking_id}")
        return JsonResponse({
            "success": True,
            "booking_id": booking.booking_id,
            "movie": booking.show.movie.title,
            "seats": [bs.seat_code for bs in booking.booking_seats.all()],
            "subtotal": float(booking.subtotal),
            "discount": float(booking.discount_amount),
            "total_amount": float(booking.total_amount),
            "redirect_url": reverse("booking_confirmation", kwargs={"booking_id": booking.booking_id})
        }, status=201)

    except SeatUnavailableError as e:
        return JsonResponse({"success": False, "error": str(e)}, status=409)
    except (InvalidSeatCodeError, CouponError, BookingError) as e:
        return JsonResponse({"success": False, "error": str(e)}, status=400)
    except Exception as e:
        return JsonResponse({
            "success": False,
            "error": f"An unexpected error occurred while processing your booking: {str(e)}"
        }, status=500)


@require_POST
def coupon_validate_api(request):
    """
    POST /api/coupons/validate/
    Validates a coupon code and calculates the discount on a provisional subtotal.
    Payload: { "code": "CINE10", "subtotal": 500.00 }
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
    except Exception:
        data = request.POST

    code = (data.get("code") or "").strip().upper()
    try:
        subtotal = Decimal(str(data.get("subtotal", 0.00)))
    except Exception:
        subtotal = Decimal("0.00")

    if not code:
        return JsonResponse({"valid": False, "message": "Coupon code is empty."}, status=400)

    try:
        coupon = Coupon.objects.get(code=code)
        if not coupon.is_currently_valid():
            return JsonResponse({
                "valid": False,
                "message": f"Coupon '{code}' is inactive or has expired."
            }, status=200)

        discount = coupon.calculate_discount(subtotal)
        return JsonResponse({
            "valid": True,
            "code": coupon.code,
            "discount_percentage": float(coupon.discount_percentage),
            "discount_amount": float(discount),
            "formatted_discount": format_inr(discount),
            "message": f"Coupon {coupon.code} applied! {coupon.discount_percentage}% discount (saved {format_inr(discount)})."
        })
    except Coupon.DoesNotExist:
        return JsonResponse({
            "valid": False,
            "message": f"Coupon code '{code}' is invalid."
        }, status=200)


@require_http_methods(["GET", "POST"])
def booking_detail_api(request, booking_id):
    """
    GET /api/bookings/<booking_id>/
    POST /api/bookings/<booking_id>/cancel/
    Protected endpoint accessible only to the booking owner or staff.
    """
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Authentication required"}, status=401)

    try:
        booking = Booking.objects.select_related("show__movie", "show__theatre", "user").get(
            booking_id=booking_id
        )
    except Booking.DoesNotExist:
        return JsonResponse({"error": f"Booking '{booking_id}' not found"}, status=404)

    if booking.user != request.user and not request.user.is_staff:
        return JsonResponse({"error": "Unauthorized access to this booking"}, status=403)

    if request.method == "POST":
        # Cancel booking
        service = BookingService()
        try:
            result = service.cancel_booking(request.user, booking_id)
            return JsonResponse({
                "success": True,
                "message": f"Booking {booking_id} has been cancelled.",
                **result
            })
        except CancellationError as e:
            return JsonResponse({"success": False, "error": str(e)}, status=400)

    # GET response
    return JsonResponse({
        "booking_id": booking.booking_id,
        "movie": booking.show.movie.title,
        "theatre": booking.show.theatre.name,
        "screen": booking.show.theatre.screen_name,
        "show_date": booking.show.show_date.isoformat(),
        "show_time": booking.show.start_time.strftime("%I:%M %p"),
        "seats": [
            {
                "seat_code": bs.seat_code,
                "seat_type": bs.seat_type,
                "price": float(bs.price_snapshot)
            }
            for bs in booking.booking_seats.all()
        ],
        "subtotal": float(booking.subtotal),
        "discount_amount": float(booking.discount_amount),
        "total_amount": float(booking.total_amount),
        "refund_amount": float(booking.refund_amount),
        "status": booking.status,
        "created_at": booking.created_at.isoformat(),
        "cancelled_at": booking.cancelled_at.isoformat() if booking.cancelled_at else None,
    })


# ============================================================================
# TEMPLATE VIEWS
# ============================================================================

@login_required
@ensure_csrf_cookie
def booking_confirmation_view(request, booking_id):
    """
    Renders the printable, cinematic booking confirmation ticket page.
    Strictly protected: users can only view their own booking.
    """
    booking = get_object_or_404(
        Booking.objects.select_related("show__movie", "show__theatre", "user")
        .prefetch_related("booking_seats"),
        booking_id=booking_id
    )

    if booking.user != request.user and not request.user.is_staff:
        return HttpResponseForbidden("You do not have permission to view this booking.")

    refund_preview = (booking.total_amount * Decimal("0.80")).quantize(Decimal("0.01"))
    cancellation_fee_preview = (booking.total_amount - refund_preview).quantize(Decimal("0.01"))

    context = {
        "booking": booking,
        "movie": booking.show.movie,
        "theatre": booking.show.theatre,
        "show": booking.show,
        "booking_seats": booking.booking_seats.all(),
        "refund_preview": refund_preview,
        "cancellation_fee_preview": cancellation_fee_preview,
        "refund_preview_inr": format_inr(refund_preview),
        "cancellation_fee_inr": format_inr(cancellation_fee_preview),
    }
    return render(request, "bookings/booking_confirmation.html", context)


@login_required
@ensure_csrf_cookie
def my_bookings_view(request):
    """
    Renders list of bookings belonging to the currently logged in user.
    """
    user_bookings = (
        Booking.objects.filter(user=request.user)
        .select_related("show__movie", "show__theatre")
        .prefetch_related("booking_seats")
        .order_by("-created_at")
    )

    context = {
        "bookings": user_bookings,
        "total_bookings": user_bookings.count(),
    }
    return render(request, "bookings/my_bookings.html", context)


@login_required
@require_POST
def cancel_booking_view(request, booking_id):
    """
    Form submission handler for cancelling a booking from the web UI.
    """
    service = BookingService()
    try:
        result = service.cancel_booking(request.user, booking_id)
        refund_str = format_inr(result["refund_amount"])
        messages.success(
            request,
            f"Booking {booking_id} has been cancelled successfully. "
            f"An 80% refund of {refund_str} has been initiated."
        )
    except CancellationError as e:
        messages.error(request, str(e))
    except Exception as e:
        messages.error(request, f"Unable to cancel booking: {str(e)}")

    next_url = request.POST.get("next") or reverse("my_bookings")
    return redirect(next_url)


# ============================================================================
# AUTHENTICATION VIEWS
# ============================================================================

@ensure_csrf_cookie
def register_view(request):
    """
    Custom user registration view.
    """
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        form = CineBookRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Welcome to CineBook, {user.first_name or user.username}! Your account has been created.")
            next_url = request.GET.get("next") or request.POST.get("next") or "home"
            return redirect(next_url)
    else:
        form = CineBookRegistrationForm()

    next_param = request.GET.get("next", "")
    return render(request, "registration/register.html", {"form": form, "next": next_param})


@ensure_csrf_cookie
def login_view(request):
    """
    Custom user login view with redirect retention.
    """
    if request.user.is_authenticated:
        return redirect("home")

    next_param = request.GET.get("next") or request.POST.get("next") or "home"

    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.first_name or user.username}!")
            return redirect(next_param)
        else:
            messages.error(request, "Invalid username or password. Please try again.")
    else:
        form = AuthenticationForm()

    return render(request, "registration/login.html", {"form": form, "next": next_param})


def logout_view(request):
    """
    User logout view.
    """
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("home")
