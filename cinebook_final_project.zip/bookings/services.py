"""
Booking Service Layer for CineBook.
Implements the Bookable interface, business logic for pricing, coupons,
atomic seat reservations, cancellations with 80% refund calculation,
and the academic 5x8 two-dimensional array matrix representation.
"""

from decimal import Decimal
from typing import List, Optional, Tuple, Dict, Any
from django.db import transaction
from django.contrib.auth.models import User
from django.utils import timezone
from core.enums import SeatType, BookingStatus
from core.interfaces import Bookable
from core.utils import (
    parse_and_validate_seat_code,
    BookingError,
    SeatUnavailableError,
    InvalidSeatCodeError,
    CouponError,
    CancellationError,
    VALID_ROWS,
    VALID_SEAT_NUMBERS
)
from cinema.models import Show, Seat
from bookings.models import Booking, BookingSeat, Coupon


class BookingIdGenerator:
    """
    Generates human-readable, sequential, unique booking IDs like 'BK1001', 'BK1002'.
    Employs database transaction boundaries to prevent collisions.
    """
    PREFIX = "BK"
    BASE_START = 1000

    @classmethod
    def generate(cls) -> str:
        """
        Determines the next available booking ID.
        """
        last_booking = Booking.objects.order_by("-id").first()
        if not last_booking:
            next_num = cls.BASE_START + 1
        else:
            # Extract number from 'BK1001' or fallback to ID offset
            raw_id = last_booking.booking_id
            if raw_id.startswith(cls.PREFIX) and raw_id[len(cls.PREFIX):].isdigit():
                current_num = int(raw_id[len(cls.PREFIX):])
                next_num = max(current_num + 1, cls.BASE_START + 1)
            else:
                next_num = cls.BASE_START + last_booking.id + 1

        candidate = f"{cls.PREFIX}{next_num}"
        # Safeguard collision check
        while Booking.objects.filter(booking_id=candidate).exists():
            next_num += 1
            candidate = f"{cls.PREFIX}{next_num}"
        return candidate


def calculate_total(
    seats: List[Seat],
    coupon_code: Optional[str] = None
) -> Tuple[Decimal, Decimal, Decimal, Optional[Coupon]]:
    """
    Computes pricing with or without coupon (Python equivalent of method overloading).
    Single source of truth: Seat prices are strictly evaluated using the SeatType enum.

    Args:
        seats: List of Seat instances
        coupon_code: Optional coupon code string (e.g. 'CINE10')

    Returns:
        (subtotal, discount_amount, final_total, coupon_instance)
    """
    if not seats:
        return Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), None

    subtotal = Decimal("0.00")
    for seat in seats:
        # Resolve price from SeatType enum
        seat_enum = SeatType.from_code(seat.seat_type)
        subtotal += seat_enum.price

    subtotal = subtotal.quantize(Decimal("0.01"))
    discount = Decimal("0.00")
    coupon_obj: Optional[Coupon] = None

    if coupon_code:
        cleaned_code = coupon_code.strip().upper()
        try:
            coupon = Coupon.objects.get(code=cleaned_code)
            if not coupon.is_currently_valid():
                raise CouponError(f"Coupon '{cleaned_code}' is inactive or has expired.")
            discount = coupon.calculate_discount(subtotal)
            coupon_obj = coupon
        except Coupon.DoesNotExist:
            raise CouponError(f"Coupon code '{cleaned_code}' is not valid.")

    final_total = max(Decimal("0.00"), subtotal - discount).quantize(Decimal("0.01"))
    return subtotal, discount, final_total, coupon_obj


def build_seat_matrix_2d(show: Show) -> List[List[Dict[str, Any]]]:
    """
    Builds a genuine two-dimensional Python array (5 rows x 8 columns)
    using nested loops to satisfy the academic OOP requirements.
    Array-based 5x8 representation mapping to database Seat models:
      Rows: A=0, B=1, C=2, D=3, E=4
      Cols: 1=0, 2=1, ..., 8=7
    """
    # Fetch all seats for this show and map by (row_label, seat_number)
    show_seats = {
        (s.row_label, s.seat_number): s
        for s in show.seats.all()
    }

    # Initialize 5x8 matrix: 5 outer row lists
    matrix: List[List[Dict[str, Any]]] = []

    for row_idx, row_label in enumerate(VALID_ROWS):
        row_list: List[Dict[str, Any]] = []
        for col_idx, seat_num in enumerate(VALID_SEAT_NUMBERS):
            seat_record = show_seats.get((row_label, seat_num))
            if seat_record:
                seat_type_enum = SeatType.from_code(seat_record.seat_type)
                seat_data = {
                    "id": seat_record.id,
                    "seat_code": f"{row_label}{seat_num}",
                    "row_label": row_label,
                    "seat_number": seat_num,
                    "seat_type": seat_type_enum.code,
                    "seat_type_label": seat_type_enum.label,
                    "price": float(seat_type_enum.price),
                    "formatted_price": f"₹{seat_type_enum.price:.2f}",
                    "is_booked": seat_record.is_booked,
                    "matrix_coords": (row_idx, col_idx),
                }
            else:
                # Fallback for unseeded seat
                expected_type = SeatType.from_row(row_label)
                seat_data = {
                    "id": None,
                    "seat_code": f"{row_label}{seat_num}",
                    "row_label": row_label,
                    "seat_number": seat_num,
                    "seat_type": expected_type.code,
                    "seat_type_label": expected_type.label,
                    "price": float(expected_type.price),
                    "formatted_price": f"₹{expected_type.price:.2f}",
                    "is_booked": False,
                    "matrix_coords": (row_idx, col_idx),
                }
            row_list.append(seat_data)
        matrix.append(row_list)

    return matrix


class BookingService(Bookable):
    """
    Service layer implementing the Bookable interface contract.
    Encapsulates all booking and cancellation workflows with transactions.
    """

    @classmethod
    def get_show_seat_matrix(cls, show_id: int) -> Tuple[Show, List[List[Dict[str, Any]]]]:
        """
        Retrieves the show and generates the 2D seat matrix.
        """
        try:
            show = Show.objects.select_related("movie", "theatre").get(id=show_id, is_active=True)
        except Show.DoesNotExist:
            raise BookingError(f"Active show with ID {show_id} does not exist.")

        matrix = build_seat_matrix_2d(show)
        return show, matrix

    def book_seats(
        self,
        user: User,
        show_id: int,
        seat_codes: List[str],
        coupon_code: Optional[str] = None
    ) -> Booking:
        """
        All-or-nothing atomic booking execution.
        Locks seat rows, validates availability and price, marks seats booked,
        and generates a confirmed booking record.
        """
        if not user or not user.is_authenticated:
            raise BookingError("You must be logged in to book movie tickets.")

        if not seat_codes or not isinstance(seat_codes, list):
            raise InvalidSeatCodeError("Please select at least one seat to book.")

        # 1. Normalize and deduplicate seat codes
        normalized_codes = []
        seen = set()
        for raw in seat_codes:
            row, num = parse_and_validate_seat_code(raw)
            code = f"{row}{num}"
            if code in seen:
                raise InvalidSeatCodeError(f"Duplicate seat code '{code}' requested.")
            seen.add(code)
            normalized_codes.append((row, num, code))

        # 2. Transactional execution with database isolation
        with transaction.atomic():
            # Verify active show
            try:
                show = Show.objects.select_related("movie", "theatre").get(id=show_id, is_active=True)
            except Show.DoesNotExist:
                raise BookingError(f"Show #{show_id} is unavailable or does not exist.")

            # Select and lock requested seats using select_for_update
            # SQLite does not block row locks, but transaction.atomic() handles table-level locking
            requested_seats: List[Seat] = []
            for row, num, code in normalized_codes:
                try:
                    seat = Seat.objects.select_for_update().get(
                        show=show,
                        row_label=row,
                        seat_number=num
                    )
                    requested_seats.append(seat)
                except Seat.DoesNotExist:
                    raise BookingError(f"Seat '{code}' does not exist for this show.")

            # Check if any seat is already booked
            already_booked = [s.seat_code for s in requested_seats if s.is_booked]
            if already_booked:
                seats_str = ", ".join(already_booked)
                raise SeatUnavailableError(
                    f"Selected seat(s) {seats_str} are already booked. Please choose other seats."
                )

            # 3. Server-side price and coupon verification
            subtotal, discount, total, coupon_obj = calculate_total(requested_seats, coupon_code)

            # 4. Generate unique Booking ID
            booking_id = BookingIdGenerator.generate()

            # 5. Create Booking record
            booking = Booking.objects.create(
                booking_id=booking_id,
                user=user,
                show=show,
                subtotal=subtotal,
                coupon_code=coupon_obj.code if coupon_obj else None,
                discount_amount=discount,
                total_amount=total,
                refund_amount=Decimal("0.00"),
                status=BookingStatus.CONFIRMED.code,
            )

            # 6. Reserve seats and create snapshot records
            for seat in requested_seats:
                seat.is_booked = True
                seat.save(update_fields=["is_booked"])

                BookingSeat.objects.create(
                    booking=booking,
                    seat=seat,
                    seat_code=seat.seat_code,
                    row_label=seat.row_label,
                    seat_number=seat.seat_number,
                    seat_type=seat.seat_type,
                    price_snapshot=SeatType.from_code(seat.seat_type).price
                )

            return booking

    def cancel_booking(self, user: User, booking_id: str) -> Dict[str, Any]:
        """
        Transactional cancellation of a confirmed booking.
        Refund policy: 80% of actual paid total amount.
        Cancellation fee: 20%.
        Releases reserved seats while preserving historical booking seat snapshots.
        """
        if not user or not user.is_authenticated:
            raise CancellationError("Authentication required to cancel a booking.")

        with transaction.atomic():
            try:
                booking = Booking.objects.select_for_update().select_related("show", "user").get(
                    booking_id=booking_id
                )
            except Booking.DoesNotExist:
                raise CancellationError(f"Booking with ID '{booking_id}' not found.")

            # Verify ownership
            if booking.user != user and not user.is_staff:
                raise CancellationError("You do not have permission to cancel this booking.")

            # Verify status
            if booking.status == BookingStatus.CANCELLED.code:
                raise CancellationError(
                    f"Booking '{booking_id}' has already been cancelled."
                )

            # 80% refund calculation
            refund_rate = Decimal("0.80")
            refund_amount = (booking.total_amount * refund_rate).quantize(Decimal("0.01"))
            cancellation_fee = (booking.total_amount - refund_amount).quantize(Decimal("0.01"))

            # Update booking status
            booking.status = BookingStatus.CANCELLED.code
            booking.refund_amount = refund_amount
            booking.cancelled_at = timezone.now()
            booking.save(update_fields=["status", "refund_amount", "cancelled_at"])

            # Release reserved seats
            released_seats = []
            for b_seat in booking.booking_seats.all():
                if b_seat.seat:
                    seat = b_seat.seat
                    seat.is_booked = False
                    seat.save(update_fields=["is_booked"])
                    released_seats.append(b_seat.seat_code)

            return {
                "booking_id": booking.booking_id,
                "status": booking.status,
                "total_paid": booking.total_amount,
                "refund_amount": refund_amount,
                "cancellation_fee": cancellation_fee,
                "refund_percentage": 80,
                "released_seats": released_seats,
                "cancelled_at": booking.cancelled_at.isoformat(),
            }
