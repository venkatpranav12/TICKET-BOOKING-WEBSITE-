from decimal import Decimal
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from core.enums import BookingStatus, SeatType
from cinema.models import Show, Seat


class Coupon(models.Model):
    """
    Promotional coupon codes for booking discounts.
    E.g. CINE10 gives a 10% discount.
    """
    code = models.CharField(max_length=30, unique=True, db_index=True)
    discount_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("10.00"),
        help_text="Percentage discount, e.g. 10.00 for 10%"
    )
    is_active = models.BooleanField(default=True)
    valid_from = models.DateTimeField(null=True, blank=True)
    valid_until = models.DateTimeField(null=True, blank=True)
    maximum_discount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Optional ceiling limit for the discount in INR"
    )

    def __str__(self):
        return f"{self.code} ({self.discount_percentage}% off)"

    def is_currently_valid(self) -> bool:
        """Checks if coupon is active and within valid date window."""
        if not self.is_active:
            return False
        now = timezone.now()
        if self.valid_from and now < self.valid_from:
            return False
        if self.valid_until and now > self.valid_until:
            return False
        return True

    def calculate_discount(self, subtotal: Decimal) -> Decimal:
        """Computes monetary discount amount based on subtotal."""
        if not self.is_currently_valid() or subtotal <= Decimal("0.00"):
            return Decimal("0.00")
        raw_discount = (subtotal * self.discount_percentage) / Decimal("100.00")
        if self.maximum_discount and raw_discount > self.maximum_discount:
            raw_discount = self.maximum_discount
        return raw_discount.quantize(Decimal("0.01"))


class Booking(models.Model):
    """
    Represents a ticket booking order placed by a registered user.
    """
    booking_id = models.CharField(max_length=20, unique=True, db_index=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookings")
    show = models.ForeignKey(Show, on_delete=models.CASCADE, related_name="bookings")
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    coupon_code = models.CharField(max_length=30, blank=True, null=True)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    status = models.CharField(
        max_length=20,
        choices=BookingStatus.choices(),
        default=BookingStatus.CONFIRMED.code,
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.booking_id} - {self.show.movie.title} ({self.status})"

    @property
    def is_confirmed(self) -> bool:
        return self.status == BookingStatus.CONFIRMED.code

    @property
    def is_cancelled(self) -> bool:
        return self.status == BookingStatus.CANCELLED.code

    @property
    def seat_codes_display(self) -> str:
        """Formatted comma-separated seat codes (e.g. 'A1, A2')"""
        return ", ".join(self.booking_seats.values_list("seat_code", flat=True))


class BookingSeat(models.Model):
    """
    Normalized snapshot record of a seat associated with a booking.
    Preserves historical seat allocation and pricing snapshot even after cancellation.
    """
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="booking_seats")
    seat = models.ForeignKey(
        Seat,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="historical_bookings"
    )
    seat_code = models.CharField(max_length=10)
    row_label = models.CharField(max_length=2)
    seat_number = models.PositiveSmallIntegerField()
    seat_type = models.CharField(max_length=20)
    price_snapshot = models.DecimalField(max_digits=8, decimal_places=2)

    class Meta:
        ordering = ["row_label", "seat_number"]

    def __str__(self):
        return f"{self.booking.booking_id} -> {self.seat_code} (₹{self.price_snapshot})"
