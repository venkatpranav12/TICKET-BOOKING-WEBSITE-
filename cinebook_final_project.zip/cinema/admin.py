from django.contrib import admin
from cinema.models import Theatre, Show, Seat


@admin.register(Theatre)
class TheatreAdmin(admin.ModelAdmin):
    list_display = ("name", "screen_name", "location", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "location")


class SeatInline(admin.TabularInline):
    model = Seat
    extra = 0
    readonly_fields = ("row_label", "seat_number", "seat_type")
    can_delete = False


@admin.register(Show)
class ShowAdmin(admin.ModelAdmin):
    list_display = ("movie", "theatre", "show_date", "start_time", "is_active")
    list_filter = ("show_date", "is_active", "theatre")
    search_fields = ("movie__title", "theatre__name")


@admin.register(Seat)
class SeatAdmin(admin.ModelAdmin):
    list_display = ("show", "row_label", "seat_number", "seat_type", "is_booked")
    list_filter = ("seat_type", "is_booked", "row_label")
    search_fields = ("show__movie__title",)
