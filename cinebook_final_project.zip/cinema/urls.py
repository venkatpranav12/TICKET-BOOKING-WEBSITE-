from django.urls import path
from cinema import views

urlpatterns = [
    path("schedule/", views.schedule_view, name="schedule"),
    path("shows/<int:show_id>/seats/", views.show_seats_view, name="show_seats"),
    path("api/shows/<int:show_id>/seats/", views.show_seats_api, name="api_show_seats"),
    path("api/shows/<int:show_id>/seats/json/", views.show_seats_api, name="show_seats_api"),
]
