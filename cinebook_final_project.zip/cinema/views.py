import json
from datetime import date, timedelta
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from cinema.models import Show, Theatre, schedule_upcoming_shows
from movies.models import Movie
from core.enums import SeatType
from bookings.services import BookingService, build_seat_matrix_2d


@ensure_csrf_cookie
def schedule_view(request):
    """
    Renders the master cinema show schedule with date picker and direct links to seat maps.
    """
    today = date.today()
    if Show.objects.filter(show_date__gte=today, is_active=True).count() == 0:
        schedule_upcoming_shows(7)

    # Date selector: next 7 days
    date_options = []
    for i in range(7):
        d = today + timedelta(days=i)
        date_options.append({
            "date": d,
            "iso": d.isoformat(),
            "label": "Today" if i == 0 else ("Tomorrow" if i == 1 else d.strftime("%a, %d %b")),
            "short_day": d.strftime("%a"),
            "day_num": d.strftime("%d"),
            "month": d.strftime("%b"),
        })

    selected_date_str = request.GET.get("date", "").strip()
    selected_theatre_id = request.GET.get("theatre", "").strip()
    selected_movie_id = request.GET.get("movie", "").strip()

    try:
        selected_date = date.fromisoformat(selected_date_str) if selected_date_str else today
    except ValueError:
        selected_date = today

    shows_qs = (
        Show.objects.filter(show_date=selected_date, is_active=True)
        .select_related("movie", "theatre")
        .prefetch_related("seats")
        .order_by("movie__title", "start_time")
    )

    if selected_theatre_id:
        shows_qs = shows_qs.filter(theatre_id=selected_theatre_id)
    if selected_movie_id:
        shows_qs = shows_qs.filter(movie_id=selected_movie_id)

    # Group shows by movie: { movie: [shows] }
    shows_by_movie = {}
    for s in shows_qs:
        shows_by_movie.setdefault(s.movie, []).append(s)

    all_theatres = Theatre.objects.filter(is_active=True)
    all_movies = Movie.objects.filter(is_now_showing=True)

    context = {
        "date_options": date_options,
        "selected_date": selected_date,
        "selected_date_iso": selected_date.isoformat(),
        "selected_theatre_id": int(selected_theatre_id) if selected_theatre_id.isdigit() else None,
        "selected_movie_id": int(selected_movie_id) if selected_movie_id.isdigit() else None,
        "shows_by_movie": shows_by_movie,
        "total_shows": shows_qs.count(),
        "theatres": all_theatres,
        "movies": all_movies,
    }
    return render(request, "cinema/schedule.html", context)


@ensure_csrf_cookie
def show_seats_view(request, show_id):
    """
    Renders interactive 5x8 seat map page for a specific show.
    """
    show = get_object_or_404(Show.objects.select_related("movie", "theatre"), id=show_id, is_active=True)
    matrix = build_seat_matrix_2d(show)
    pricing = SeatType.to_pricing_dict()

    context = {
        "show": show,
        "movie": show.movie,
        "theatre": show.theatre,
        "matrix": matrix,
        "pricing_json": json.dumps(pricing),
        "pricing": pricing,
    }
    return render(request, "cinema/seat_selection.html", context)


def show_seats_api(request, show_id):
    """
    GET /api/shows/<show_id>/seats/
    Returns live seat availability map as JSON for client-side rendering/refresh.
    """
    try:
        show = Show.objects.select_related("movie", "theatre").get(id=show_id, is_active=True)
    except Show.DoesNotExist:
        return JsonResponse({"error": "Show not found or inactive"}, status=404)

    matrix = build_seat_matrix_2d(show)
    pricing = SeatType.to_pricing_dict()

    return JsonResponse({
        "show_id": show.id,
        "movie_title": show.movie.title,
        "theatre_name": show.theatre.name,
        "screen_name": show.theatre.screen_name,
        "show_date": show.show_date.isoformat(),
        "start_time": show.start_time.strftime("%I:%M %p"),
        "pricing": pricing,
        "seat_matrix": matrix,
        "total_seats": show.get_total_seats_count(),
        "available_seats": show.get_available_seats_count(),
    })
