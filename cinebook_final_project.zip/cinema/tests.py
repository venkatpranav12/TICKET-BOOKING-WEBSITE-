from datetime import date, time, timedelta
from decimal import Decimal
from django.test import TestCase, Client
from django.urls import reverse
from movies.models import Movie
from cinema.models import Theatre, Show, Seat, schedule_upcoming_shows
from core.enums import SeatType


class CinemaScheduleAndSeatMapTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.movie = Movie.objects.create(
            title="Inception",
            slug="inception",
            description="A mind-bending heist thriller.",
            is_now_showing=True,
            rating=Decimal("8.8"),
            duration_minutes=148,
            release_date=date(2010, 7, 16),
        )
        self.theatre = Theatre.objects.create(
            name="CineBook Grand",
            screen_name="Audi 1 - Dolby Atmos",
            location="City Center",
            is_active=True,
        )
        self.show = Show.objects.create(
            movie=self.movie,
            theatre=self.theatre,
            show_date=date.today(),
            start_time=time(18, 0),
            is_active=True,
        )

    def test_auto_seat_generation_creates_40_seats(self):
        """Creating a show must automatically generate 40 seats (5 rows x 8 cols) with correct pricing."""
        seats = Seat.objects.filter(show=self.show)
        self.assertEqual(seats.count(), 40)

        # Verify rows A-E
        rows = sorted(list(set(seats.values_list("row_label", flat=True))))
        self.assertEqual(rows, ["A", "B", "C", "D", "E"])

        # Verify seat pricing: Regular (A,B), Premium (C,D), VIP (E)
        reg_seats = seats.filter(row_label__in=["A", "B"])
        self.assertEqual(reg_seats.count(), 16)
        for s in reg_seats:
            self.assertEqual(s.price, Decimal("150.00"))

        prem_seats = seats.filter(row_label__in=["C", "D"])
        self.assertEqual(prem_seats.count(), 16)
        for s in prem_seats:
            self.assertEqual(s.price, Decimal("250.00"))

        vip_seats = seats.filter(row_label="E")
        self.assertEqual(vip_seats.count(), 8)
        for s in vip_seats:
            self.assertEqual(s.price, Decimal("400.00"))

    def test_schedule_upcoming_shows_creates_daily_inventory(self):
        """Calling schedule_upcoming_shows must schedule upcoming shows with seats."""
        created = schedule_upcoming_shows(days_ahead=3)
        self.assertGreaterEqual(created, 1)
        future_date = date.today() + timedelta(days=2)
        future_shows = Show.objects.filter(show_date=future_date, is_active=True)
        self.assertTrue(future_shows.exists())
        for f_show in future_shows:
            self.assertEqual(f_show.seats.count(), 40)

    def test_schedule_page_view(self):
        """Schedule page must render date tabs, movies, and direct seat map links."""
        url = reverse("schedule")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Showtimes &amp; Seating Map")
        self.assertContains(response, "Inception")
        self.assertContains(response, reverse("show_seats", args=[self.show.id]))

    def test_schedule_page_filters(self):
        """Schedule page theatre and movie filters work correctly."""
        url = reverse("schedule") + f"?theatre={self.theatre.id}&movie={self.movie.id}"
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.movie.title)

    def test_show_seats_view(self):
        """Seat selection view renders the 5x8 interactive seating map."""
        url = reverse("show_seats", args=[self.show.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Screen This Way")
        self.assertContains(response, "data-show-id")
        self.assertContains(response, "seat-grid")
        self.assertContains(response, "seat-btn")

    def test_show_seats_api(self):
        """Seat map JSON API returns 5x8 matrix and live seat counts."""
        url = reverse("show_seats_api", args=[self.show.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["show_id"], self.show.id)
        self.assertEqual(data["total_seats"], 40)
        self.assertEqual(data["available_seats"], 40)
        self.assertEqual(len(data["seat_matrix"]), 5) # 5 rows
        for row in data["seat_matrix"]:
            self.assertEqual(len(row), 8) # 8 cols
