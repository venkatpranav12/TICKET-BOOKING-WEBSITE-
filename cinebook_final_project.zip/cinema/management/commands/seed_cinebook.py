"""
Management command to seed initial CineBook data:
- Sample movies (Interstellar, Inception, The Dark Knight, Dune 2, Spider-Man, The Martian)
- Theatres & Shows
- 40 independent seats (5 rows A-E x 8 cols 1-8) per show
- CINE10 coupon
- Demo user (cinefan / Cinebook@2026)
Safe to re-run multiple times without duplicate records.
"""

from datetime import date, time, timedelta
from decimal import Decimal
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from movies.models import Movie
from cinema.models import Theatre, Show, Seat
from bookings.models import Coupon
from core.enums import SeatType
from core.utils import VALID_ROWS, VALID_SEAT_NUMBERS


class Command(BaseCommand):
    help = "Seeds initial movies, theatres, shows, seats, and coupons for CineBook"

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE("==> Seeding CineBook Database..."))

        # 1. Seed Demo User
        demo_user, created = User.objects.get_or_create(
            username="cinefan",
            defaults={
                "email": "fan@cinebook.com",
                "first_name": "Cinema",
                "last_name": "Fan",
                "is_active": True,
            }
        )
        if created:
            demo_user.set_password("Cinebook@2026")
            demo_user.save()
            self.stdout.write(self.style.SUCCESS("  + Created demo user: cinefan / Cinebook@2026"))
        else:
            self.stdout.write("  * Demo user 'cinefan' already exists.")

        # 2. Seed Movies
        movies_data = [
            {
                "title": "Interstellar",
                "slug": "interstellar",
                "description": "When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft, along with a team of researchers, to find a new planet for humans.",
                "poster_url": "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=600&auto=format&fit=crop&q=80",
                "backdrop_url": "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1400&auto=format&fit=crop&q=80",
                "genre": "Sci-Fi, Adventure, Drama",
                "language": "English",
                "duration_minutes": 169,
                "rating": Decimal("8.7"),
                "release_date": date(2014, 11, 7),
                "is_now_showing": True,
            },
            {
                "title": "Inception",
                "slug": "inception",
                "description": "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project.",
                "poster_url": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
                "backdrop_url": "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=1400&auto=format&fit=crop&q=80",
                "genre": "Action, Sci-Fi, Thriller",
                "language": "English",
                "duration_minutes": 148,
                "rating": Decimal("8.8"),
                "release_date": date(2010, 7, 16),
                "is_now_showing": True,
            },
            {
                "title": "The Dark Knight",
                "slug": "the-dark-knight",
                "description": "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
                "poster_url": "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=600&auto=format&fit=crop&q=80",
                "backdrop_url": "https://images.unsplash.com/photo-1514565131-fce0801e5785?w=1400&auto=format&fit=crop&q=80",
                "genre": "Action, Crime, Drama",
                "language": "English",
                "duration_minutes": 152,
                "rating": Decimal("9.0"),
                "release_date": date(2008, 7, 18),
                "is_now_showing": True,
            },
            {
                "title": "Dune: Part Two",
                "slug": "dune-part-two",
                "description": "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family, facing a choice between the love of his life and the fate of the universe.",
                "poster_url": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80",
                "backdrop_url": "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1400&auto=format&fit=crop&q=80",
                "genre": "Action, Adventure, Sci-Fi",
                "language": "English",
                "duration_minutes": 166,
                "rating": Decimal("8.6"),
                "release_date": date(2024, 3, 1),
                "is_now_showing": True,
            },
            {
                "title": "Spider-Man: Across the Spider-Verse",
                "slug": "spider-man-across-the-spider-verse",
                "description": "Miles Morales catapults across the Multiverse, where he encounters a team of Spider-People charged with protecting its very existence. When heroes clash, Miles must redefine what it means to be a hero.",
                "poster_url": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80",
                "backdrop_url": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1400&auto=format&fit=crop&q=80",
                "genre": "Animation, Action, Adventure",
                "language": "English",
                "duration_minutes": 140,
                "rating": Decimal("8.7"),
                "release_date": date(2023, 6, 2),
                "is_now_showing": True,
            },
            {
                "title": "The Martian",
                "slug": "the-martian",
                "description": "An astronaut becomes stranded on Mars after his team assume him dead, and must rely on his ingenuity to find a way to signal to Earth that he is alive and survive until a potential rescue.",
                "poster_url": "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=600&auto=format&fit=crop&q=80",
                "backdrop_url": "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1400&auto=format&fit=crop&q=80",
                "genre": "Adventure, Drama, Sci-Fi",
                "language": "English",
                "duration_minutes": 144,
                "rating": Decimal("8.0"),
                "release_date": date(2015, 10, 2),
                "is_now_showing": False,
            },
        ]

        movies = {}
        for m_data in movies_data:
            movie, _ = Movie.objects.update_or_create(
                slug=m_data["slug"],
                defaults=m_data
            )
            movies[m_data["slug"]] = movie
            self.stdout.write(f"  + Synced movie: {movie.title}")

        # 3. Seed Theatres
        theatre_main, _ = Theatre.objects.update_or_create(
            name="CineBook Dolby Atmos Grand",
            screen_name="Audi 1 - Laser 4K",
            defaults={
                "location": "Central Boulevard, Downtown",
                "is_active": True,
            }
        )
        theatre_imax, _ = Theatre.objects.update_or_create(
            name="CineBook IMAX Sapphire",
            screen_name="IMAX GT 70mm",
            defaults={
                "location": "Cyber Park Mall, North City",
                "is_active": True,
            }
        )
        self.stdout.write(f"  + Synced theatres: {theatre_main.name}, {theatre_imax.name}")

        # 4. Seed Shows
        today = date.today()
        tomorrow = today + timedelta(days=1)
        day_after = today + timedelta(days=2)

        shows_schedule = [
            # Interstellar shows
            (movies["interstellar"], theatre_main, today, time(14, 30)),
            (movies["interstellar"], theatre_imax, tomorrow, time(18, 45)),
            (movies["interstellar"], theatre_main, day_after, time(21, 15)),

            # Inception shows
            (movies["inception"], theatre_main, today, time(18, 0)),
            (movies["inception"], theatre_imax, tomorrow, time(14, 0)),

            # The Dark Knight shows
            (movies["the-dark-knight"], theatre_imax, today, time(20, 30)),
            (movies["the-dark-knight"], theatre_main, tomorrow, time(21, 30)),

            # Dune 2 shows
            (movies["dune-part-two"], theatre_imax, today, time(15, 15)),
            (movies["dune-part-two"], theatre_main, tomorrow, time(17, 30)),

            # Spider-Man shows
            (movies["spider-man-across-the-spider-verse"], theatre_main, today, time(11, 0)),
            (movies["spider-man-across-the-spider-verse"], theatre_imax, tomorrow, time(11, 30)),
        ]

        total_seats_created = 0
        shows_created = 0

        for movie_obj, theatre_obj, show_date_val, start_time_val in shows_schedule:
            show, s_created = Show.objects.get_or_create(
                movie=movie_obj,
                theatre=theatre_obj,
                show_date=show_date_val,
                start_time=start_time_val,
                defaults={"is_active": True}
            )
            if s_created:
                shows_created += 1

            # 5. Generate independent 5x8 seat inventory (40 seats) for each show
            for row_label in VALID_ROWS:
                seat_type = SeatType.from_row(row_label)
                for seat_num in VALID_SEAT_NUMBERS:
                    _, seat_created = Seat.objects.get_or_create(
                        show=show,
                        row_label=row_label,
                        seat_number=seat_num,
                        defaults={
                            "seat_type": seat_type.code,
                            "is_booked": False,
                        }
                    )
                    if seat_created:
                        total_seats_created += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"  + Synced {len(shows_schedule)} shows with 40 independent seats per show "
                f"({total_seats_created} seats created)."
            )
        )

        # 6. Seed Coupon CINE10
        coupon, _ = Coupon.objects.update_or_create(
            code="CINE10",
            defaults={
                "discount_percentage": Decimal("10.00"),
                "is_active": True,
                "maximum_discount": Decimal("500.00"),
            }
        )
        self.stdout.write(self.style.SUCCESS(f"  + Synced coupon: {coupon.code} (10% off)"))

        self.stdout.write(self.style.SUCCESS("==> CineBook database seeding completed successfully!"))
