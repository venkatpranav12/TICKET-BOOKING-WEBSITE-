from decimal import Decimal
from django.db import models
from core.enums import SeatType
from movies.models import Movie


class Theatre(models.Model):
    """
    Represents a cinema hall/theatre complex.
    """
    name = models.CharField(max_length=150)
    location = models.CharField(max_length=200)
    screen_name = models.CharField(max_length=50, default="Screen 1 - IMAX")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} - {self.screen_name} ({self.location})"


class Show(models.Model):
    """
    Represents a specific movie screening at a theatre, date, and start time.
    Each show maintains its own isolated 5x8 seat inventory.
    """
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name="shows")
    theatre = models.ForeignKey(Theatre, on_delete=models.CASCADE, related_name="shows")
    show_date = models.DateField(db_index=True)
    start_time = models.TimeField(db_index=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["show_date", "start_time"]
        unique_together = ("movie", "theatre", "show_date", "start_time")

    def __str__(self):
        return f"{self.movie.title} @ {self.theatre.name} on {self.show_date} {self.start_time.strftime('%I:%M %p')}"

    @property
    def formatted_time(self) -> str:
        return self.start_time.strftime("%I:%M %p")

    @property
    def formatted_date(self) -> str:
        return self.show_date.strftime("%a, %d %b %Y")

    def get_available_seats_count(self) -> int:
        return self.seats.filter(is_booked=False).count()

    def get_total_seats_count(self) -> int:
        return self.seats.count()

    def generate_seats_if_needed(self):
        """
        Ensures this show has a complete 5x8 inventory (Rows A-E, Cols 1-8).
        Creates any missing seats with appropriate category from SeatType.
        """
        from core.utils import VALID_ROWS, VALID_SEAT_NUMBERS
        existing_coords = set(self.seats.values_list("row_label", "seat_number"))
        seats_to_create = []
        for row in VALID_ROWS:
            st = SeatType.from_row(row)
            for num in VALID_SEAT_NUMBERS:
                if (row, num) not in existing_coords:
                    seats_to_create.append(
                        Seat(
                            show=self,
                            row_label=row,
                            seat_number=num,
                            seat_type=st.code,
                            is_booked=False
                        )
                    )
        if seats_to_create:
            Seat.objects.bulk_create(seats_to_create, ignore_conflicts=True)


class Seat(models.Model):
    """
    Represents an individual seat for a specific Show.
    Maintains 5x8 layout: Rows A-E, Seat numbers 1-8.
    """
    show = models.ForeignKey(Show, on_delete=models.CASCADE, related_name="seats")
    row_label = models.CharField(max_length=2)
    seat_number = models.PositiveSmallIntegerField()
    seat_type = models.CharField(
        max_length=20,
        choices=SeatType.choices(),
        default=SeatType.REGULAR.code
    )
    is_booked = models.BooleanField(default=False, db_index=True)

    class Meta:
        ordering = ["row_label", "seat_number"]
        constraints = [
            models.UniqueConstraint(
                fields=["show", "row_label", "seat_number"],
                name="unique_show_row_seat"
            )
        ]

    def __str__(self):
        return f"{self.seat_code} ({self.seat_type}) - {'Booked' if self.is_booked else 'Available'}"

    @property
    def seat_code(self) -> str:
        return f"{self.row_label}{self.seat_number}"

    @property
    def price(self) -> Decimal:
        """Single source of truth for price from SeatType enum"""
        try:
            return SeatType.from_code(self.seat_type).price
        except ValueError:
            return SeatType.REGULAR.price

    @property
    def category_label(self) -> str:
        try:
            return SeatType.from_code(self.seat_type).label
        except ValueError:
            return "Regular"


from django.db.models.signals import post_save
from django.dispatch import receiver


@receiver(post_save, sender=Show)
def auto_generate_show_seats(sender, instance, created, **kwargs):
    """
    Automatically creates all 40 seats (5 rows x 8 cols) whenever a Show is scheduled.
    """
    if created or instance.seats.count() < 40:
        instance.generate_seats_if_needed()


def schedule_upcoming_shows(days_ahead: int = 7) -> int:
    """
    Schedules active daily shows for all currently showing movies across available theatres.
    Generates 40-seat inventory for each show across today and upcoming days.
    Returns the total number of new shows created.
    """
    from datetime import date, time, timedelta
    today = date.today()
    movies = list(Movie.objects.filter(is_now_showing=True))
    theatres = list(Theatre.objects.filter(is_active=True))
    if not movies or not theatres:
        return 0

    standard_times = [
        time(11, 0),   # 11:00 AM Morning Show
        time(14, 30),  # 02:30 PM Matinee Show
        time(18, 0),   # 06:00 PM Evening Show
        time(21, 15),  # 09:15 PM Night Show
    ]

    shows_created = 0
    for day_offset in range(days_ahead + 1):
        target_date = today + timedelta(days=day_offset)
        for m_idx, movie in enumerate(movies):
            theatre = theatres[(m_idx + day_offset) % len(theatres)]
            # Assign two distinct show times per movie per day
            slot_indices = [(m_idx + day_offset) % len(standard_times), (m_idx + day_offset + 2) % len(standard_times)]
            for s_idx in set(slot_indices):
                slot_time = standard_times[s_idx]
                show, created = Show.objects.get_or_create(
                    movie=movie,
                    theatre=theatre,
                    show_date=target_date,
                    start_time=slot_time,
                    defaults={"is_active": True}
                )
                if created:
                    shows_created += 1
                show.generate_seats_if_needed()

    return shows_created
